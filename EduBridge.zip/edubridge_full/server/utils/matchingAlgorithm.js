const rankTutors = (student, tutors) => {
  return tutors.map(tutor => {
    let score = 0;
    const reasons = [];
    const common = (student.subjectsNeeded || []).filter(s =>
      (tutor.subjects || []).map(t => t.toLowerCase()).includes(s.toLowerCase()));
    score += student.subjectsNeeded?.length ? (common.length / student.subjectsNeeded.length) * 35 : 17;
    if (common.length) reasons.push('Teaches: ' + common.join(', '));
    const compat = { visual:['visual'], auditory:['lecture','socratic'], reading:['lecture'], kinesthetic:['hands-on'] };
    const styleMatch = (compat[student.learningStyle] || []).includes(tutor.teachingStyle);
    score += styleMatch ? 20 : 6;
    if (styleMatch) reasons.push('Teaching style matches your learning preference');
    score += (tutor.averageRating / 5) * 15;
    if (tutor.averageRating >= 4) reasons.push('Rated ' + tutor.averageRating + '/5 stars');
    score += 5;
    return { tutor, score: Math.round(score), reasons, commonSubjects: common };
  }).sort((a, b) => b.score - a.score);
};
module.exports = { rankTutors };
