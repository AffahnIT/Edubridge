const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { protect, requireRole } = require('../middleware/authMiddleware');
const { rankTutors } = require('../utils/matchingAlgorithm');
router.get('/', protect, requireRole('student'), async (req, res) => {
  try {
    const student = await User.findById(req.user._id);
    const tutors = await User.find({ role: 'tutor', isActive: true }).select('-password');
    const ranked = rankTutors(student, tutors);
    res.json({ matches: ranked.map(r => ({ tutor: r.tutor, score: r.score, reasons: r.reasons })) });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
module.exports = router;
