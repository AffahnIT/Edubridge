const express = require('express');
const router = express.Router();
const Session = require('../models/Session');
const { protect, requireRole } = require('../middleware/authMiddleware');
router.use(protect);
router.post('/', requireRole('student'), async (req, res) => {
  try {
    const { tutorId, subject, date, startTime, endTime, notes } = req.body;
    const [sh, sm] = startTime.split(':').map(Number);
    const [eh, em] = endTime.split(':').map(Number);
    const session = await Session.create({
      student: req.user._id, tutor: tutorId, subject, date,
      startTime, endTime, durationMinutes: (eh*60+em)-(sh*60+sm), notes
    });
    res.status(201).json({ message: 'Session booked!', session });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
router.get('/', async (req, res) => {
  try {
    const filter = req.user.role === 'student' ? { student: req.user._id } : { tutor: req.user._id };
    const sessions = await Session.find(filter)
      .populate('student','name email').populate('tutor','name email subjects').sort({ date: -1 });
    res.json({ sessions });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
router.put('/:id/status', requireRole('tutor'), async (req, res) => {
  try {
    const session = await Session.findOneAndUpdate(
      { _id: req.params.id, tutor: req.user._id }, { status: req.body.status }, { new: true });
    if (!session) return res.status(404).json({ message: 'Session not found' });
    res.json({ session });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
module.exports = router;
