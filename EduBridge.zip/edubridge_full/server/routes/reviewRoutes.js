const express = require('express');
const router = express.Router();
const Review = require('../models/Review');
const Session = require('../models/Session');
const { protect, requireRole } = require('../middleware/authMiddleware');
router.post('/', protect, requireRole('student'), async (req, res) => {
  try {
    const { sessionId, rating, comment } = req.body;
    const session = await Session.findOne({ _id: sessionId, student: req.user._id, status: 'completed' });
    if (!session) return res.status(400).json({ message: 'Session not found or not completed' });
    if (session.isReviewed) return res.status(400).json({ message: 'Already reviewed' });
    const review = await Review.create({ session: sessionId, student: req.user._id, tutor: session.tutor, rating, comment });
    await Session.findByIdAndUpdate(sessionId, { isReviewed: true });
    res.status(201).json({ review });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
router.get('/tutor/:tutorId', async (req, res) => {
  try {
    const reviews = await Review.find({ tutor: req.params.tutorId }).populate('student','name').sort({ createdAt: -1 });
    res.json({ reviews });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
module.exports = router;
