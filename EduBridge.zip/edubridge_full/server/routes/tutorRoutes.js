const express = require('express');
const router = express.Router();
const User = require('../models/User');
router.get('/', async (req, res) => {
  try {
    const { search, subject } = req.query;
    let query = { role: 'tutor', isActive: true };
    if (subject) query.subjects = { $in: [new RegExp(subject, 'i')] };
    if (search) query.$or = [{ name: new RegExp(search,'i') }, { bio: new RegExp(search,'i') }, { subjects: { $in: [new RegExp(search,'i')] } }];
    const tutors = await User.find(query).select('-password');
    res.json({ count: tutors.length, tutors });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
router.get('/:id', async (req, res) => {
  try {
    const tutor = await User.findOne({ _id: req.params.id, role: 'tutor' }).select('-password');
    if (!tutor) return res.status(404).json({ message: 'Tutor not found' });
    res.json({ tutor });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
module.exports = router;
