const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { protect } = require('../middleware/authMiddleware');
router.get('/profile', protect, (req, res) => res.json({ user: req.user }));
router.put('/profile', protect, async (req, res) => {
  try {
    const fields = ['name','bio','location','phone','avatar','learningStyle','academicLevel',
      'goals','subjectsNeeded','availability','subjects','teachingStyle','hourlyRate','yearsExperience','languages','qualifications'];
    const updates = {};
    fields.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });
    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true }).select('-password');
    res.json({ message: 'Profile updated', user });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
module.exports = router;
