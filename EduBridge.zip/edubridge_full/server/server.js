require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const connectDB = require('./config/db');

const app = express();
connectDB();

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:3000', credentials: true }));
app.use(express.json());
app.use(morgan('dev'));

app.use('/api/auth',     require('./routes/authRoutes'));
app.use('/api/users',    require('./routes/userRoutes'));
app.use('/api/tutors',   require('./routes/tutorRoutes'));
app.use('/api/sessions', require('./routes/sessionRoutes'));
app.use('/api/reviews',  require('./routes/reviewRoutes'));
app.use('/api/match',    require('./routes/matchRoutes'));

app.get('/api/health', (req, res) => res.json({ status: 'EduBridge API running!', time: new Date() }));
app.use((req, res) => res.status(404).json({ message: 'Route not found' }));
app.use((err, req, res, next) => res.status(500).json({ message: err.message }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`\n🚀 EduBridge server running on http://localhost:${PORT}\n`));
