const mongoose = require('mongoose');
const reviewSchema = new mongoose.Schema({
  session: { type: mongoose.Schema.Types.ObjectId, ref: 'Session', required: true, unique: true },
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  tutor:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  rating:  { type: Number, required: true, min: 1, max: 5 },
  comment: { type: String, maxlength: 500 },
}, { timestamps: true });

reviewSchema.post('save', async function() {
  const User = require('./User');
  const stats = await this.constructor.aggregate([
    { $match: { tutor: this.tutor } },
    { $group: { _id: '$tutor', avg: { $avg: '$rating' }, count: { $sum: 1 } } }
  ]);
  if (stats.length > 0) {
    await User.findByIdAndUpdate(this.tutor, {
      averageRating: Math.round(stats[0].avg * 10) / 10,
      totalReviews: stats[0].count
    });
  }
});
module.exports = mongoose.model('Review', reviewSchema);
