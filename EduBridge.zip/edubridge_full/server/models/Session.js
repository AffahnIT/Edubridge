const mongoose = require('mongoose');
const sessionSchema = new mongoose.Schema({
  student:         { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  tutor:           { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  subject:         { type: String, required: true },
  date:            { type: Date, required: true },
  startTime:       { type: String, required: true },
  endTime:         { type: String, required: true },
  durationMinutes: { type: Number, required: true },
  status:          { type: String, enum: ['pending','confirmed','completed','cancelled'], default: 'pending' },
  notes:           { type: String, default: '' },
  meetingLink:     { type: String, default: '' },
  price:           { type: Number, default: 0 },
  isReviewed:      { type: Boolean, default: false },
}, { timestamps: true });
module.exports = mongoose.model('Session', sessionSchema);
