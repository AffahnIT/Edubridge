const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name:            { type: String, required: true, trim: true },
  email:           { type: String, required: true, unique: true, lowercase: true },
  password:        { type: String, required: true, minlength: 6, select: false },
  role:            { type: String, enum: ['student','tutor'], required: true },
  avatar:          { type: String, default: '' },
  bio:             { type: String, default: '' },
  location:        { type: String, default: '' },
  phone:           { type: String, default: '' },
  subjects:        [String],
  teachingStyle:   { type: String, default: '' },
  hourlyRate:      { type: Number, default: 0 },
  yearsExperience: { type: Number, default: 0 },
  qualifications:  [String],
  languages:       [String],
  learningStyle:   { type: String, default: '' },
  academicLevel:   { type: String, default: '' },
  goals:           [String],
  subjectsNeeded:  [String],
  availability:    [{ day: String, startTime: String, endTime: String }],
  averageRating:   { type: Number, default: 0 },
  totalReviews:    { type: Number, default: 0 },
  totalSessions:   { type: Number, default: 0 },
  isActive:        { type: Boolean, default: true },
}, { timestamps: true });

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});
userSchema.methods.matchPassword = async function(entered) {
  return await bcrypt.compare(entered, this.password);
};
module.exports = mongoose.model('User', userSchema);
