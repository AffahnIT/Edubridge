import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/common/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import TutorList from './pages/TutorList';
import TutorDetail from './pages/TutorDetail';
import Profile from './pages/Profile';
import Sessions from './pages/Sessions';
import Matches from './pages/Matches';

const Protected = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <div className="spinner" />;
  return user ? children : <Navigate to="/login" replace />;
};
const PublicOnly = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <div className="spinner" />;
  return user ? <Navigate to="/dashboard" replace /> : children;
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Navbar />
        <Routes>
          <Route path="/"           element={<Home />} />
          <Route path="/login"      element={<PublicOnly><Login /></PublicOnly>} />
          <Route path="/register"   element={<PublicOnly><Register /></PublicOnly>} />
          <Route path="/tutors"     element={<TutorList />} />
          <Route path="/tutors/:id" element={<TutorDetail />} />
          <Route path="/dashboard"  element={<Protected><Dashboard /></Protected>} />
          <Route path="/profile"    element={<Protected><Profile /></Protected>} />
          <Route path="/sessions"   element={<Protected><Sessions /></Protected>} />
          <Route path="/matches"    element={<Protected><Matches /></Protected>} />
          <Route path="*"           element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
export default App;
