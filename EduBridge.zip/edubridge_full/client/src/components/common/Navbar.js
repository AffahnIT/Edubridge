import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  return (
    <nav style={{ background:'#fff', borderBottom:'1px solid #E5E7EB', position:'sticky', top:0, zIndex:100, boxShadow:'0 1px 8px rgba(76,29,149,0.06)' }}>
      <div style={{ maxWidth:'1200px', margin:'0 auto', padding:'0 24px', height:'64px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <Link to="/" style={{ textDecoration:'none', fontSize:'22px', fontWeight:'700' }}>
          <span style={{ color:'#4C1D95' }}>Edu</span><span style={{ color:'#E63946' }}>Bridge</span>
        </Link>
        <div style={{ display:'flex', gap:'24px', alignItems:'center' }}>
          <Link to="/tutors" style={{ color:'#374151', textDecoration:'none', fontWeight:'500' }}>Find Tutors</Link>
          {user && <Link to="/matches"  style={{ color:'#374151', textDecoration:'none', fontWeight:'500' }}>Matches</Link>}
          {user && <Link to="/sessions" style={{ color:'#374151', textDecoration:'none', fontWeight:'500' }}>Sessions</Link>}
        </div>
        <div style={{ display:'flex', gap:'12px', alignItems:'center' }}>
          {user ? (
            <>
              <Link to="/dashboard" style={{ color:'#374151', textDecoration:'none', fontWeight:'500' }}>👋 {user.name.split(' ')[0]}</Link>
              <button onClick={() => { logout(); navigate('/'); }} className="btn btn-outline" style={{ padding:'7px 16px', fontSize:'14px' }}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login"    className="btn btn-outline" style={{ padding:'7px 16px', fontSize:'14px' }}>Login</Link>
              <Link to="/register" className="btn btn-primary" style={{ padding:'7px 16px', fontSize:'14px' }}>Sign Up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};
export default Navbar;
