import axios from 'axios';
const api = axios.create({ baseURL: 'http://localhost:5000/api', headers: { 'Content-Type': 'application/json' } });
api.interceptors.request.use(config => {
  const token = localStorage.getItem('edubridge_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});
api.interceptors.response.use(r => r, err => {
  if (err.response?.status === 401) {
    localStorage.removeItem('edubridge_token');
    localStorage.removeItem('edubridge_user');
    window.location.href = '/login';
  }
  return Promise.reject(err);
});
export default api;
export const authAPI    = { register: d => api.post('/auth/register', d), login: d => api.post('/auth/login', d), getMe: () => api.get('/auth/me') };
export const tutorAPI   = { getAll: p => api.get('/tutors', { params: p }), getById: id => api.get(`/tutors/${id}`) };
export const sessionAPI = { book: d => api.post('/sessions', d), getMyAll: () => api.get('/sessions'), setStatus: (id, s) => api.put(`/sessions/${id}/status`, { status: s }) };
export const reviewAPI  = { create: d => api.post('/reviews', d), getForTutor: id => api.get(`/reviews/tutor/${id}`) };
export const matchAPI   = { getMatches: () => api.get('/match') };
export const userAPI    = { updateProfile: d => api.put('/users/profile', d), getProfile: () => api.get('/users/profile') };
