import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';
const AuthContext = createContext(null);
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = localStorage.getItem('edubridge_token');
    const u = localStorage.getItem('edubridge_user');
    if (t && u) { setUser(JSON.parse(u)); api.defaults.headers.common['Authorization'] = `Bearer ${t}`; }
    setLoading(false);
  }, []);
  const login = (userData, token) => {
    setUser(userData);
    localStorage.setItem('edubridge_token', token);
    localStorage.setItem('edubridge_user', JSON.stringify(userData));
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  };
  const logout = () => {
    setUser(null);
    localStorage.removeItem('edubridge_token');
    localStorage.removeItem('edubridge_user');
    delete api.defaults.headers.common['Authorization'];
  };
  const updateUser = u => { setUser(u); localStorage.setItem('edubridge_user', JSON.stringify(u)); };
  return <AuthContext.Provider value={{ user, loading, login, logout, updateUser }}>{children}</AuthContext.Provider>;
};
export const useAuth = () => useContext(AuthContext);
export default AuthContext;
