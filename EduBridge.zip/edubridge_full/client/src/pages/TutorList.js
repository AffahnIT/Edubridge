import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { tutorAPI } from '../services/api';

const TutorList = () => {
  const [tutors, setTutors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetchTutors = async () => {
    setLoading(true);
    try { const res = await tutorAPI.getAll({ search }); setTutors(res.data.tutors); }
    catch {}
    finally { setLoading(false); }
  };

  useEffect(() => { fetchTutors(); }, []);

  return (
    <div className="container" style={{ padding:'40px 24px' }}>
      <h1 style={{ fontSize:'28px', fontWeight:'700', marginBottom:'8px' }}>Find Tutors</h1>
      <p style={{ color:'#6B7280', marginBottom:'24px' }}>Browse our network of qualified, rated tutors</p>
      <form onSubmit={e=>{e.preventDefault();fetchTutors();}} style={{ display:'flex', gap:'12px', marginBottom:'32px' }}>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by name, subject, or keyword..."
          style={{ flex:1, padding:'10px 14px', border:'1.5px solid #E5E7EB', borderRadius:'8px', fontSize:'15px' }} />
        <button type="submit" className="btn btn-primary">Search</button>
        {search && <button type="button" className="btn btn-outline" onClick={()=>{setSearch('');fetchTutors();}}>Clear</button>}
      </form>

      {loading ? <div className="spinner" /> : (
        <>
          <p style={{ color:'#6B7280', marginBottom:'20px', fontSize:'14px' }}>{tutors.length} tutor(s) found</p>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(290px,1fr))', gap:'20px' }}>
            {tutors.map(t => (
              <div key={t._id} className="card" style={{ padding:'20px' }}>
                <div style={{ display:'flex', gap:'14px', alignItems:'center', marginBottom:'12px' }}>
                  <div style={{ width:'52px', height:'52px', borderRadius:'50%', background:'#EDE9FE', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'22px', fontWeight:'700', color:'#4C1D95', flexShrink:0 }}>
                    {t.name[0].toUpperCase()}
                  </div>
                  <div>
                    <h3 style={{ fontWeight:'700', fontSize:'16px' }}>{t.name}</h3>
                    {t.averageRating>0 && <span style={{ fontSize:'13px', color:'#6B7280' }}><span className="star">★</span> {t.averageRating} ({t.totalReviews} reviews)</span>}
                  </div>
                </div>
                <p style={{ fontSize:'14px', color:'#6B7280', marginBottom:'12px', lineHeight:1.5 }}>
                  {t.bio?.slice(0,100) || 'No bio yet.'}{t.bio?.length>100?'...':''}
                </p>
                <div style={{ display:'flex', flexWrap:'wrap', gap:'6px', marginBottom:'14px' }}>
                  {(t.subjects||[]).slice(0,3).map(s=><span key={s} className="badge badge-primary">{s}</span>)}
                  {(t.subjects||[]).length>3 && <span className="badge badge-primary">+{t.subjects.length-3}</span>}
                </div>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                  {t.hourlyRate>0 ? <span style={{ fontWeight:'700', color:'#4C1D95' }}>${t.hourlyRate}/hr</span> : <span/>}
                  <Link to={`/tutors/${t._id}`} className="btn btn-primary" style={{ padding:'7px 14px', fontSize:'13px' }}>View Profile</Link>
                </div>
              </div>
            ))}
            {tutors.length===0 && (
              <div style={{ gridColumn:'1/-1', textAlign:'center', padding:'48px', color:'#6B7280' }}>
                <div style={{ fontSize:'48px', marginBottom:'16px' }}>🔍</div>
                <p>No tutors found. Try a different search term.</p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};
export default TutorList;
