import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';

const Register = () => {
  const [form, setForm] = useState({ name:'', email:'', password:'', role:'student' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async e => {
    e.preventDefault(); setError(''); setLoading(true);
    try { const res = await authAPI.register(form); login(res.data.user, res.data.token); navigate('/profile'); }
    catch (err) { setError(err.response?.data?.message || 'Registration failed.'); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight:'80vh', display:'flex', alignItems:'center', justifyContent:'center', padding:'24px' }}>
      <div className="card" style={{ width:'100%', maxWidth:'440px' }}>
        <h2 style={{ fontSize:'26px', fontWeight:'700', marginBottom:'24px' }}>Create your account</h2>
        <div style={{ display:'flex', gap:'12px', marginBottom:'20px' }}>
          {['student','tutor'].map(r => (
            <button key={r} type="button" onClick={()=>setForm({...form,role:r})}
              style={{ flex:1, padding:'12px', border:'2px solid', borderRadius:'8px', cursor:'pointer',
                borderColor: form.role===r?'#4C1D95':'#E5E7EB',
                background: form.role===r?'#EDE9FE':'white',
                color: form.role===r?'#4C1D95':'#374151', fontWeight:'500', fontSize:'14px' }}>
              {r==='student'?'📚 I am a Student':'🎓 I am a Tutor'}
            </button>
          ))}
        </div>
        {error && <div className="error-box">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group"><label>Full Name</label><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Your full name" required /></div>
          <div className="form-group"><label>Email</label><input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com" required /></div>
          <div className="form-group"><label>Password</label><input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="At least 6 characters" required /></div>
          <button type="submit" className="btn btn-primary" style={{ width:'100%', justifyContent:'center', padding:'12px', marginTop:'8px' }} disabled={loading}>
            {loading?'Creating account...':'Create Account'}
          </button>
        </form>
        <p style={{ textAlign:'center', marginTop:'20px', color:'#6B7280', fontSize:'14px' }}>
          Have account? <Link to="/login" style={{ color:'#4C1D95', fontWeight:'600' }}>Log in</Link>
        </p>
      </div>
    </div>
  );
};
export default Register;
