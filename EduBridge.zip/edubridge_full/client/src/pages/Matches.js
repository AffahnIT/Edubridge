import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { matchAPI } from '../services/api';

const Matches = () => {
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    matchAPI.getMatches()
      .then(r => setMatches(r.data.matches))
      .catch(e => setError(e.response?.data?.message || 'Failed to load matches'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="spinner" />;

  return (
    <div className="container" style={{ padding:'40px 24px' }}>
      <h1 style={{ fontSize:'28px', fontWeight:'700', marginBottom:'8px' }}>Your AI Matches 🤖</h1>
      <p style={{ color:'#6B7280', marginBottom:'8px' }}>Tutors ranked by compatibility with your learning profile.</p>
      <p style={{ color:'#6B7280', marginBottom:'32px', fontSize:'14px' }}>
        <Link to="/profile" style={{ color:'#4C1D95' }}>Update your profile</Link> to improve match accuracy.
      </p>

      {error && <div className="error-box">{error}</div>}

      {matches.length===0 && !error ? (
        <div className="card" style={{ textAlign:'center', padding:'48px' }}>
          <div style={{ fontSize:'48px', marginBottom:'16px' }}>🔍</div>
          <h3 style={{ fontWeight:'700', marginBottom:'8px' }}>No matches yet</h3>
          <p style={{ color:'#6B7280', marginBottom:'20px' }}>Complete your profile with subjects and learning style to get matched!</p>
          <Link to="/profile" className="btn btn-primary">Complete Profile</Link>
        </div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:'20px' }}>
          {matches.map(({ tutor, score, reasons }, i) => (
            <div key={tutor._id} className="card" style={{ display:'flex', gap:'20px', alignItems:'flex-start' }}>
              <div style={{ background: i===0?'#4C1D95':i===1?'#7C3AED':'#A78BFA', color:'white', borderRadius:'50%', width:'44px', height:'44px', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'800', fontSize:'16px', flexShrink:0 }}>
                #{i+1}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', justifyContent:'space-between', flexWrap:'wrap', gap:'8px', marginBottom:'8px' }}>
                  <h3 style={{ fontSize:'18px', fontWeight:'700' }}>{tutor.name}</h3>
                  <div style={{ display:'flex', alignItems:'center', gap:'10px' }}>
                    <div style={{ width:'120px', height:'8px', background:'#E5E7EB', borderRadius:'4px' }}>
                      <div style={{ width:`${score}%`, height:'100%', borderRadius:'4px', background: score>70?'#10B981':score>40?'#F59E0B':'#EF4444' }} />
                    </div>
                    <span style={{ fontWeight:'700', color:'#4C1D95', fontSize:'14px' }}>{score}% match</span>
                  </div>
                </div>

                <div style={{ display:'flex', flexWrap:'wrap', gap:'6px', marginBottom:'8px' }}>
                  {(tutor.subjects||[]).map(s=><span key={s} className="badge badge-primary">{s}</span>)}
                </div>

                {reasons.length>0 && (
                  <div style={{ marginBottom:'12px' }}>
                    {reasons.map((r,j)=><div key={j} style={{ fontSize:'13px', color:'#059669', display:'flex', alignItems:'center', gap:'4px' }}>✅ {r}</div>)}
                  </div>
                )}

                <div style={{ display:'flex', gap:'10px', alignItems:'center', flexWrap:'wrap' }}>
                  <Link to={`/tutors/${tutor._id}`} className="btn btn-primary" style={{ padding:'7px 16px', fontSize:'14px' }}>View Profile & Book</Link>
                  {tutor.hourlyRate>0 && <span style={{ fontSize:'14px', color:'#4C1D95', fontWeight:'600' }}>${tutor.hourlyRate}/hr</span>}
                  {tutor.averageRating>0 && <span style={{ fontSize:'14px', color:'#6B7280' }}><span className="star">★</span> {tutor.averageRating}</span>}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
export default Matches;
