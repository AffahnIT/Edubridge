import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';

const Login = () => {
  const [form, setForm] = useState({ email:'', password:'' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async e => {
    e.preventDefault(); setError(''); setLoading(true);
    try { const res = await authAPI.login(form); login(res.data.user, res.data.token); navigate('/dashboard'); }
    catch (err) { setError(err.response?.data?.message || 'Login failed. Try again.'); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight:'80vh', display:'flex', alignItems:'center', justifyContent:'center', padding:'24px' }}>
      <div className="card" style={{ width:'100%', maxWidth:'440px' }}>
        <h2 style={{ fontSize:'26px', fontWeight:'700', marginBottom:'8px' }}>Welcome back 👋</h2>
        <p style={{ color:'#6B7280', marginBottom:'24px' }}>Log in to your EduBridge account</p>
        {error && <div className="error-box">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email</label>
            <input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com" required />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="••••••••" required />
          </div>
          <button type="submit" className="btn btn-primary" style={{ width:'100%', justifyContent:'center', padding:'12px', marginTop:'8px' }} disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>
        <p style={{ textAlign:'center', marginTop:'20px', color:'#6B7280', fontSize:'14px' }}>
          No account? <Link to="/register" style={{ color:'#4C1D95', fontWeight:'600' }}>Sign up free</Link>
        </p>
      </div>
    </div>
  );
};
export default Login;
