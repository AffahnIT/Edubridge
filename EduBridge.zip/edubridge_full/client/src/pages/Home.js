import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => (
  <div>
    <section style={{ background:'linear-gradient(135deg,#EDE9FE 0%,#F0F4FF 100%)', padding:'80px 24px', textAlign:'center' }}>
      <div style={{ maxWidth:'720px', margin:'0 auto' }}>
        <h1 style={{ fontSize:'48px', fontWeight:'800', lineHeight:1.2, marginBottom:'20px', color:'#1A1A2E' }}>
          Connect with the <span style={{ color:'#7C3AED' }}>perfect tutor</span><br/>for your learning journey
        </h1>
        <p style={{ fontSize:'18px', color:'#6B7280', marginBottom:'32px', lineHeight:1.6 }}>
          EduBridge uses intelligent AI matching to pair students with tutors based on learning style, subjects, and availability.
        </p>
        <div style={{ display:'flex', gap:'16px', justifyContent:'center', flexWrap:'wrap' }}>
          <Link to="/register" className="btn btn-primary" style={{ fontSize:'16px', padding:'12px 28px' }}>Get Started Free</Link>
          <Link to="/tutors"   className="btn btn-outline" style={{ fontSize:'16px', padding:'12px 28px' }}>Browse Tutors</Link>
        </div>
      </div>
    </section>

    <section style={{ display:'flex', justifyContent:'center', gap:'48px', padding:'32px 24px', background:'#4C1D95', flexWrap:'wrap' }}>
      {[['500+','Qualified Tutors'],['2,000+','Students Helped'],['15,000+','Sessions Completed'],['4.8/5','Average Rating']].map(([n,l]) => (
        <div key={l} style={{ textAlign:'center', color:'white' }}>
          <div style={{ fontSize:'32px', fontWeight:'800' }}>{n}</div>
          <div style={{ fontSize:'14px', opacity:0.8, marginTop:'4px' }}>{l}</div>
        </div>
      ))}
    </section>

    <section style={{ padding:'72px 24px', background:'#F8F7FF' }}>
      <div className="container">
        <h2 style={{ textAlign:'center', fontSize:'32px', fontWeight:'700', marginBottom:'16px' }}>Why EduBridge?</h2>
        <p style={{ textAlign:'center', color:'#6B7280', marginBottom:'40px' }}>Everything you need for personalized learning in one platform</p>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))', gap:'24px' }}>
          {[
            ['🤖','AI-Powered Matching','Smart algorithm finds your most compatible tutor based on subjects, learning style, and availability.'],
            ['📅','Easy Booking','Book sessions in seconds. Manage your schedule and track all upcoming lessons.'],
            ['⭐','Verified Tutors','All tutors are rated by real students. Read honest reviews before deciding.'],
            ['💬','Personalized Learning','Sessions tailored to your learning style — visual, auditory, hands-on, or reading-based.'],
          ].map(([icon,title,desc]) => (
            <div key={title} className="card" style={{ textAlign:'center', padding:'32px 24px' }}>
              <div style={{ fontSize:'40px', marginBottom:'16px' }}>{icon}</div>
              <h3 style={{ fontSize:'18px', fontWeight:'700', marginBottom:'12px' }}>{title}</h3>
              <p style={{ color:'#6B7280', lineHeight:1.6 }}>{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section style={{ background:'#4C1D95', color:'white', textAlign:'center', padding:'72px 24px' }}>
      <h2 style={{ fontSize:'32px', fontWeight:'700', marginBottom:'16px' }}>Ready to start learning?</h2>
      <p style={{ opacity:0.8, marginBottom:'32px', fontSize:'18px' }}>Join thousands of students finding their ideal tutors today.</p>
      <Link to="/register" className="btn" style={{ background:'white', color:'#4C1D95', fontSize:'16px', padding:'12px 32px', fontWeight:'700' }}>Create Free Account</Link>
    </section>
  </div>
);
export default Home;
