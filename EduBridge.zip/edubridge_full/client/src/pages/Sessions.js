import React, { useEffect, useState } from 'react';
import { sessionAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

const STATUS_COLORS = {
  pending:   { bg:'#FEF3C7', color:'#92400E' },
  confirmed: { bg:'#D1FAE5', color:'#065F46' },
  completed: { bg:'#DBEAFE', color:'#1E40AF' },
  cancelled: { bg:'#FEE2E2', color:'#991B1B' },
};

const Sessions = () => {
  const { user } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  const load = () => sessionAPI.getMyAll().then(r=>setSessions(r.data.sessions)).finally(()=>setLoading(false));
  useEffect(() => { load(); }, []);

  const changeStatus = async (id, status) => {
    try { await sessionAPI.setStatus(id, status); load(); }
    catch(e) { alert(e.response?.data?.message || 'Update failed'); }
  };

  const filtered = filter==='all' ? sessions : sessions.filter(s=>s.status===filter);

  if (loading) return <div className="spinner" />;

  return (
    <div className="container" style={{ padding:'40px 24px' }}>
      <h1 style={{ fontSize:'28px', fontWeight:'700', marginBottom:'24px' }}>My Sessions</h1>

      <div style={{ display:'flex', gap:'8px', marginBottom:'24px', flexWrap:'wrap' }}>
        {['all','pending','confirmed','completed','cancelled'].map(f=>(
          <button key={f} onClick={()=>setFilter(f)}
            style={{ padding:'6px 14px', borderRadius:'20px', border:'1.5px solid', cursor:'pointer', fontSize:'13px', fontWeight:'500',
              background: filter===f?'#4C1D95':'white', color: filter===f?'white':'#374151', borderColor: filter===f?'#4C1D95':'#E5E7EB' }}>
            {f.charAt(0).toUpperCase()+f.slice(1)}
          </button>
        ))}
      </div>

      {filtered.length===0 ? (
        <div className="card" style={{ textAlign:'center', padding:'48px' }}>
          <div style={{ fontSize:'48px', marginBottom:'16px' }}>📅</div>
          <p style={{ color:'#6B7280' }}>{filter==='all'?'No sessions yet.':'No '+filter+' sessions.'}</p>
        </div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:'16px' }}>
          {filtered.map(s => {
            const c = STATUS_COLORS[s.status] || {};
            const other = user?.role==='student' ? s.tutor : s.student;
            return (
              <div key={s._id} className="card" style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:'12px' }}>
                <div>
                  <h3 style={{ fontWeight:'700', marginBottom:'4px', fontSize:'16px' }}>{s.subject}</h3>
                  <p style={{ fontSize:'14px', color:'#6B7280', marginBottom:'4px' }}>
                    {user?.role==='student'?'👨‍🏫 Tutor: ':'👨‍🎓 Student: '}<strong>{other?.name || 'Unknown'}</strong>
                  </p>
                  <p style={{ fontSize:'14px', color:'#6B7280', marginBottom:'4px' }}>
                    📅 {new Date(s.date).toLocaleDateString('en-GB',{weekday:'short',year:'numeric',month:'short',day:'numeric'})}
                  </p>
                  <p style={{ fontSize:'14px', color:'#6B7280' }}>🕐 {s.startTime} – {s.endTime} ({s.durationMinutes} min)</p>
                  {s.notes && <p style={{ fontSize:'13px', color:'#9CA3AF', marginTop:'4px', fontStyle:'italic' }}>"{s.notes}"</p>}
                </div>
                <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-end', gap:'8px' }}>
                  <span style={{ padding:'4px 14px', borderRadius:'20px', fontSize:'12px', fontWeight:'700', background:c.bg, color:c.color }}>
                    {s.status.toUpperCase()}
                  </span>
                  {user?.role==='tutor' && s.status==='pending' && (
                    <div style={{ display:'flex', gap:'8px' }}>
                      <button className="btn btn-primary" style={{ padding:'6px 12px', fontSize:'13px' }} onClick={()=>changeStatus(s._id,'confirmed')}>✓ Confirm</button>
                      <button className="btn btn-danger"  style={{ padding:'6px 12px', fontSize:'13px' }} onClick={()=>changeStatus(s._id,'cancelled')}>✗ Decline</button>
                    </div>
                  )}
                  {user?.role==='tutor' && s.status==='confirmed' && (
                    <button className="btn btn-primary" style={{ padding:'6px 12px', fontSize:'13px', background:'#10B981' }} onClick={()=>changeStatus(s._id,'completed')}>Mark Complete</button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
export default Sessions;
