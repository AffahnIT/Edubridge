import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { userAPI } from '../services/api';

const SUBJECTS = ['Math','Physics','Chemistry','Biology','English','History','Computer Science','Python','JavaScript','French','Arabic','Statistics','Economics','Geography'];
const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];

const Profile = () => {
  const { user, updateUser } = useAuth();
  const [form, setForm] = useState({ ...user });
  const [msg, setMsg] = useState(''); const [msgType, setMsgType] = useState(''); const [saving, setSaving] = useState(false);

  const set = (field, value) => setForm(f => ({ ...f, [field]: value }));
  const toggleItem = (item, field) => {
    const cur = form[field] || [];
    set(field, cur.includes(item) ? cur.filter(x=>x!==item) : [...cur, item]);
  };

  const handleSave = async e => {
    e.preventDefault(); setSaving(true); setMsg('');
    try {
      const res = await userAPI.updateProfile(form);
      updateUser(res.data.user); setMsg('Profile saved successfully!'); setMsgType('success');
    } catch(err) { setMsg(err.response?.data?.message || 'Save failed.'); setMsgType('error'); }
    finally { setSaving(false); }
  };

  const isTutor = user?.role === 'tutor';
  const SubjectBtn = ({ s, field }) => (
    <button type="button" onClick={()=>toggleItem(s,field)}
      style={{ padding:'5px 12px', borderRadius:'20px', border:'1.5px solid #4C1D95', cursor:'pointer', fontSize:'13px', transition:'all 0.15s',
        background:(form[field]||[]).includes(s)?'#4C1D95':'white', color:(form[field]||[]).includes(s)?'white':'#4C1D95' }}>
      {s}
    </button>
  );

  return (
    <div className="container" style={{ padding:'40px 24px', maxWidth:'720px' }}>
      <h1 style={{ fontSize:'28px', fontWeight:'700', marginBottom:'8px' }}>{isTutor?'🎓 Tutor Profile':'📚 Student Profile'}</h1>
      <p style={{ color:'#6B7280', marginBottom:'28px' }}>
        {isTutor ? 'A complete profile attracts more students and improves your visibility.' : 'Complete your profile to get accurate AI tutor matches.'}
      </p>

      {msg && <div className={msgType==='success'?'success-box':'error-box'}>{msg}</div>}

      <form onSubmit={handleSave}>
        <div className="card" style={{ marginBottom:'20px' }}>
          <h3 style={{ fontWeight:'700', marginBottom:'16px', color:'#4C1D95' }}>Basic Information</h3>
          <div className="form-group"><label>Full Name</label><input value={form.name||''} onChange={e=>set('name',e.target.value)} /></div>
          <div className="form-group"><label>Bio</label><textarea rows={4} value={form.bio||''} onChange={e=>set('bio',e.target.value)} placeholder={isTutor?'Describe your teaching experience, qualifications, and approach...':'Tell tutors about your learning goals and background...'} style={{resize:'vertical'}} /></div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px' }}>
            <div className="form-group"><label>Location</label><input value={form.location||''} onChange={e=>set('location',e.target.value)} placeholder="City, Country" /></div>
            <div className="form-group"><label>Phone (optional)</label><input value={form.phone||''} onChange={e=>set('phone',e.target.value)} placeholder="+1 234 567 8900" /></div>
          </div>
        </div>

        {isTutor && (
          <>
            <div className="card" style={{ marginBottom:'20px' }}>
              <h3 style={{ fontWeight:'700', marginBottom:'16px', color:'#4C1D95' }}>Teaching Details</h3>
              <div className="form-group">
                <label>Subjects I Teach</label>
                <div style={{ display:'flex', flexWrap:'wrap', gap:'8px', marginTop:'4px' }}>
                  {SUBJECTS.map(s=><SubjectBtn key={s} s={s} field="subjects" />)}
                </div>
              </div>
              <div className="form-group">
                <label>Teaching Style</label>
                <select value={form.teachingStyle||''} onChange={e=>set('teachingStyle',e.target.value)}>
                  <option value="">Select your style</option>
                  <option value="visual">Visual (diagrams, charts, videos)</option>
                  <option value="hands-on">Hands-on / Practical</option>
                  <option value="lecture">Lecture-based</option>
                  <option value="socratic">Socratic (Q&A discussion)</option>
                </select>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px' }}>
                <div className="form-group"><label>Hourly Rate (USD)</label><input type="number" min="0" value={form.hourlyRate||''} onChange={e=>set('hourlyRate',e.target.value)} placeholder="e.g. 25" /></div>
                <div className="form-group"><label>Years of Experience</label><input type="number" min="0" value={form.yearsExperience||''} onChange={e=>set('yearsExperience',e.target.value)} placeholder="e.g. 3" /></div>
              </div>
            </div>
          </>
        )}

        {!isTutor && (
          <div className="card" style={{ marginBottom:'20px' }}>
            <h3 style={{ fontWeight:'700', marginBottom:'16px', color:'#4C1D95' }}>Learning Preferences</h3>
            <div className="form-group">
              <label>My Learning Style</label>
              <select value={form.learningStyle||''} onChange={e=>set('learningStyle',e.target.value)}>
                <option value="">Select your style</option>
                <option value="visual">Visual (diagrams, videos, charts)</option>
                <option value="auditory">Auditory (listening, discussion)</option>
                <option value="reading">Reading / Writing</option>
                <option value="kinesthetic">Kinesthetic (hands-on practice)</option>
              </select>
            </div>
            <div className="form-group">
              <label>Academic Level</label>
              <select value={form.academicLevel||''} onChange={e=>set('academicLevel',e.target.value)}>
                <option value="">Select level</option>
                <option value="high-school">High School</option>
                <option value="undergraduate">Undergraduate</option>
                <option value="postgraduate">Postgraduate</option>
                <option value="professional">Professional</option>
              </select>
            </div>
            <div className="form-group">
              <label>Subjects I Need Help With</label>
              <div style={{ display:'flex', flexWrap:'wrap', gap:'8px', marginTop:'4px' }}>
                {SUBJECTS.map(s=><SubjectBtn key={s} s={s} field="subjectsNeeded" />)}
              </div>
            </div>
          </div>
        )}

        <button type="submit" className="btn btn-primary" style={{ padding:'12px 32px', fontSize:'16px' }} disabled={saving}>
          {saving ? 'Saving...' : '💾 Save Profile'}
        </button>
      </form>
    </div>
  );
};
export default Profile;
