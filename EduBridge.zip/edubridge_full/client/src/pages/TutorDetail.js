import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { tutorAPI, sessionAPI, reviewAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

const TutorDetail = () => {
  const { id } = useParams(); const { user } = useAuth(); const navigate = useNavigate();
  const [tutor, setTutor] = useState(null); const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState({ subject:'', date:'', startTime:'', endTime:'', notes:'' });
  const [msg, setMsg] = useState(''); const [msgType, setMsgType] = useState('');

  useEffect(() => {
    Promise.all([tutorAPI.getById(id), reviewAPI.getForTutor(id)])
      .then(([t,r]) => { setTutor(t.data.tutor); setReviews(r.data.reviews); })
      .finally(() => setLoading(false));
  }, [id]);

  const handleBook = async e => {
    e.preventDefault();
    if (!user) return navigate('/login');
    try {
      await sessionAPI.book({ tutorId: id, ...booking });
      setMsg('Session booked successfully! Check your Sessions page.'); setMsgType('success');
      setBooking({ subject:'', date:'', startTime:'', endTime:'', notes:'' });
    } catch(err) { setMsg(err.response?.data?.message || 'Booking failed.'); setMsgType('error'); }
  };

  if (loading) return <div className="spinner" />;
  if (!tutor) return <div style={{padding:'40px',textAlign:'center'}}><p>Tutor not found.</p><Link to="/tutors" className="btn btn-primary" style={{marginTop:'16px'}}>Back to Tutors</Link></div>;

  return (
    <div className="container" style={{ padding:'40px 24px' }}>
      <Link to="/tutors" style={{ color:'#4C1D95', textDecoration:'none', fontSize:'14px', marginBottom:'20px', display:'inline-block' }}>← Back to Tutors</Link>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 360px', gap:'32px', alignItems:'start', marginTop:'16px' }}>
        <div>
          <div className="card" style={{ marginBottom:'24px' }}>
            <div style={{ display:'flex', gap:'20px', alignItems:'center', marginBottom:'16px' }}>
              <div style={{ width:'80px', height:'80px', borderRadius:'50%', background:'#EDE9FE', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'32px', fontWeight:'700', color:'#4C1D95', flexShrink:0 }}>
                {tutor.name[0].toUpperCase()}
              </div>
              <div>
                <h1 style={{ fontSize:'24px', fontWeight:'700', marginBottom:'4px' }}>{tutor.name}</h1>
                {tutor.averageRating>0 && <p style={{ color:'#6B7280', fontSize:'14px' }}><span className="star">★</span> {tutor.averageRating}/5 ({tutor.totalReviews} reviews)</p>}
                {tutor.hourlyRate>0 && <p style={{ color:'#4C1D95', fontWeight:'700', fontSize:'16px' }}>${tutor.hourlyRate}/hour</p>}
                {tutor.location && <p style={{ color:'#6B7280', fontSize:'14px' }}>📍 {tutor.location}</p>}
              </div>
            </div>
            <p style={{ color:'#6B7280', lineHeight:1.6 }}>{tutor.bio || 'No bio provided yet.'}</p>
          </div>

          {(tutor.subjects||[]).length>0 && (
            <div className="card" style={{ marginBottom:'24px' }}>
              <h3 style={{ fontWeight:'700', marginBottom:'12px' }}>Subjects</h3>
              <div style={{ display:'flex', flexWrap:'wrap', gap:'8px' }}>
                {tutor.subjects.map(s=><span key={s} className="badge badge-primary" style={{fontSize:'13px',padding:'5px 12px'}}>{s}</span>)}
              </div>
            </div>
          )}

          {tutor.teachingStyle && (
            <div className="card" style={{ marginBottom:'24px' }}>
              <h3 style={{ fontWeight:'700', marginBottom:'8px' }}>Teaching Style</h3>
              <span className="badge badge-success" style={{fontSize:'13px',padding:'5px 12px'}}>{tutor.teachingStyle}</span>
              {tutor.yearsExperience>0 && <p style={{color:'#6B7280',marginTop:'8px',fontSize:'14px'}}>📚 {tutor.yearsExperience} years of experience</p>}
            </div>
          )}

          {reviews.length>0 && (
            <div className="card">
              <h3 style={{ fontWeight:'700', marginBottom:'16px' }}>Student Reviews ({reviews.length})</h3>
              {reviews.map(r=>(
                <div key={r._id} style={{ borderBottom:'1px solid #E5E7EB', paddingBottom:'16px', marginBottom:'16px' }}>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:'4px' }}>
                    <strong style={{fontSize:'14px'}}>{r.student?.name}</strong>
                    <span style={{color:'#F59E0B',fontSize:'14px'}}>{'★'.repeat(r.rating)}{'☆'.repeat(5-r.rating)}</span>
                  </div>
                  <p style={{ fontSize:'14px', color:'#6B7280' }}>{r.comment}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          {user?.role==='student' ? (
            <div className="card" style={{ position:'sticky', top:'80px' }}>
              <h3 style={{ fontWeight:'700', marginBottom:'16px' }}>📅 Book a Session</h3>
              {msg && <div className={msgType==='success'?'success-box':'error-box'}>{msg}</div>}
              <form onSubmit={handleBook}>
                <div className="form-group"><label>Subject</label><input type="text" value={booking.subject} onChange={e=>setBooking({...booking,subject:e.target.value})} placeholder="e.g. Calculus, Python..." required /></div>
                <div className="form-group"><label>Date</label><input type="date" value={booking.date} onChange={e=>setBooking({...booking,date:e.target.value})} required /></div>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px' }}>
                  <div className="form-group"><label>Start Time</label><input type="time" value={booking.startTime} onChange={e=>setBooking({...booking,startTime:e.target.value})} required /></div>
                  <div className="form-group"><label>End Time</label><input type="time" value={booking.endTime} onChange={e=>setBooking({...booking,endTime:e.target.value})} required /></div>
                </div>
                <div className="form-group"><label>Notes (optional)</label><textarea rows={3} value={booking.notes} onChange={e=>setBooking({...booking,notes:e.target.value})} placeholder="What topics do you need help with?" style={{resize:'vertical'}} /></div>
                <button type="submit" className="btn btn-primary" style={{ width:'100%', justifyContent:'center', padding:'12px' }}>Request Session</button>
              </form>
            </div>
          ) : !user ? (
            <div className="card" style={{ textAlign:'center', padding:'32px' }}>
              <p style={{color:'#6B7280',marginBottom:'16px'}}>Log in as a student to book this tutor</p>
              <Link to="/login" className="btn btn-primary" style={{justifyContent:'center'}}>Login to Book</Link>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};
export default TutorDetail;
