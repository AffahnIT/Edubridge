import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Dashboard = () => {
  const { user } = useAuth();
  const studentCards = [
    ['🤖','My Matches','Get AI-matched tutors','/matches','#EDE9FE','#4C1D95'],
    ['🔍','Find Tutors','Browse all tutors','/tutors','#DBEAFE','#1E40AF'],
    ['📅','My Sessions','View booked sessions','/sessions','#D1FAE5','#065F46'],
    ['👤','My Profile','Update your profile','/profile','#FEF3C7','#92400E'],
  ];
  const tutorCards = [
    ['📅','My Sessions','Manage bookings','/sessions','#D1FAE5','#065F46'],
    ['👤','My Profile','Update your profile','/profile','#FEF3C7','#92400E'],
    ['🔍','Browse','See tutor listings','/tutors','#DBEAFE','#1E40AF'],
  ];
  const cards = user?.role === 'tutor' ? tutorCards : studentCards;

  return (
    <div className="container" style={{ padding:'40px 24px' }}>
      <h1 style={{ fontSize:'28px', fontWeight:'700', marginBottom:'8px' }}>
        Welcome back, {user?.name?.split(' ')[0]} 👋
      </h1>
      <p style={{ color:'#6B7280', marginBottom:'32px' }}>
        {user?.role==='student' ? 'Find your perfect tutor and continue your learning journey.' : 'Manage your sessions and connect with students.'}
      </p>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:'20px', marginBottom:'32px' }}>
        {cards.map(([icon,title,desc,link,bg,color]) => (
          <Link key={title} to={link} style={{ textDecoration:'none' }}>
            <div className="card" style={{ textAlign:'center', padding:'32px 20px', cursor:'pointer', transition:'transform 0.2s' }}
              onMouseOver={e=>e.currentTarget.style.transform='translateY(-4px)'}
              onMouseOut={e=>e.currentTarget.style.transform='translateY(0)'}>
              <div style={{ fontSize:'36px', marginBottom:'12px' }}>{icon}</div>
              <h3 style={{ fontWeight:'700', marginBottom:'6px', fontSize:'16px' }}>{title}</h3>
              <p style={{ color:'#6B7280', fontSize:'14px' }}>{desc}</p>
            </div>
          </Link>
        ))}
      </div>
      {user?.role==='student' && (
        <div style={{ background:'#EDE9FE', borderLeft:'4px solid #4C1D95', borderRadius:'8px', padding:'16px 20px' }}>
          <h3 style={{ color:'#4C1D95', marginBottom:'6px' }}>💡 Get better matches</h3>
          <p style={{ color:'#5B21B6', fontSize:'14px' }}>
            Complete your learning profile to get more accurate tutor recommendations.{' '}
            <Link to="/profile" style={{ color:'#4C1D95', fontWeight:'700' }}>Update profile →</Link>
          </p>
        </div>
      )}
    </div>
  );
};
export default Dashboard;
