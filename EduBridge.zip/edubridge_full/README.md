# EduBridge 🎓
**Connecting Learners, Building Futures**

An intelligent EdTech platform that matches students with tutors using AI-powered recommendations.

> Final Year Project — SUP MTI | Supervised by: Madam Sara Kostan

## Team
- Usman Sani Nayaya — Project Manager & System Analyst
- Yusuf Lawal — Backend Developer  
- Fayyad Balarabe Garba — Frontend Developer
- Nwosu Chisom Enyinnaya — AI & Testing Engineer

## Quick Start

### 1. Setup Server
```bash
cd server
npm install
cp .env.example .env
# Edit .env with your MongoDB connection string
npm run dev
```

### 2. Setup Client
```bash
cd client
npm install
npm start
```

### 3. Open Browser
Visit **http://localhost:3000**

## Tech Stack
| Layer | Technology |
|-------|-----------|
| Frontend | React.js, React Router, Axios |
| Backend | Node.js, Express.js |
| Database | MongoDB Atlas |
| Auth | JWT, bcrypt |
| Deployment | Vercel + Render |
